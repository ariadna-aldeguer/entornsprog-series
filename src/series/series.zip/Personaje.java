package series;

public class Personaje {
	
	private String nombre;
	
	
}
