package series;

public class Personaje {
	
	private String nombre;

	@Override
	public String toString() {
		return "Personaje [nombre=" + nombre + "]";
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setCapitulo(Capitulo capitulo) {
		// TODO Auto-generated method stub
		
	}
}
