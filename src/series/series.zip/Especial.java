package series;

public class Especial extends Capitulo {
	
	public Especial(int duracion, int num, Temporada temporada) {
		//Datos de capitulo
		super(duracion, num, temporada);
	}
	
}
